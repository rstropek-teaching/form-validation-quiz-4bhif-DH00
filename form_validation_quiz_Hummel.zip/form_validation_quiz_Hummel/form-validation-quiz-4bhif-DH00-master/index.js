"use strict";
$("#firstName").keyup(function () {
    if ($(this).val()) {
        $("#firstNameMandatory").hide();
        validate.Submit();
    }
    else {
        $("#firstNameMandatory").show();
    }
});
$("#lastName").keyup(function () {
    if ($(this).val()) {
        $("#lastNameMandatory").hide();
        validate.Submit();
    }
    else {
        $("#lastNameMandatory").show();
    }
});
$("#newsletter").keyup(function () {
    if ($(this).val()) {
        $("#emailMandatory").show();
        validate.Submit();
    }
    else {
        $("#emailMandatory").hide();
    }
});

$("#firstName").keyup(function() {
    if($(this).val()) {
        $("#firstNameMandatory").hide();
        validate.Submit();
    } else {
        $("#firstNameMandatory").show();
    } 
});
$("#lastName").keyup(function() {
    if($(this).val()) {
        $("#lastNameMandatory").hide();
        validate.Submit();
    } else {
        $("#lastNameMandatory").show();
    } 
});
/*$("#newsletter").keyup(function() {
    if($(this).val()) {
        $("#emailMandatory").show();
        validate.Submit();
    } else {
        $("#emailMandatory").hide();
    }
});

Ansatz war die email-Mandatory auszublenden solange die
Newsletter-Checkbox nicht angekreuzt ist. Und sofern diesie
angekreuzt ist die Mandatory anzuzeigen bis eine Email-Eingabe
erfolgt. Leider konnte ich das Statement für die Abfrage 
einer Ceckbox nicht finden. Anderes sollte funktionieren.
*/